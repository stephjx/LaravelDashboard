<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-white leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="min-h-screen bg-white py-8 px-4 sm:px-6 lg:px-8 relative overflow-hidden hide-scrollbar">
        <div class="max-w-none mx-0 w-full relative z-10">
            <!-- Professional Welcome Section -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 mb-8">
                <div class="p-6 sm:p-8">
                    <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
                        <div class="flex items-center">
                            <div class="p-3 bg-blue-100 rounded-lg mr-4">
                                <i class="fas fa-user text-blue-600 text-2xl"></i>
                            </div>
                            <div>
                                <h1 class="text-2xl sm:text-3xl font-bold text-gray-900">Welcome back, <?php echo e($user->name); ?>!</h1>
                                <p class="text-gray-600 mt-1">You're successfully logged into your dashboard</p>
                            </div>
                        </div>
                        <div class="flex items-center justify-center lg:justify-end">
                            <div class="flex items-center px-3 py-2 bg-green-50 rounded-full mr-4">
                                <div class="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                                <span class="text-sm font-medium text-green-700">Online</span>
                            </div>
                            <!-- Big Polar Bear Animation -->
                            <div class="polar-bear-container relative">
                                <div class="polar-bear text-6xl lg:text-7xl animate-bounce cursor-pointer" title="Hello there!">🐻‍❄️</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Professional Stats Cards Section -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 px-4 sm:px-6 lg:px-8 mb-8">
                <!-- Total Users Card -->
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow duration-200">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm font-medium text-gray-500 uppercase tracking-wide">Total Users</p>
                            <p class="text-3xl font-bold text-gray-900 mt-1"><?php echo e($userCount); ?></p>
                            <p class="text-sm text-gray-500 mt-1">In our system</p>
                        </div>
                        <div class="p-3 bg-blue-50 rounded-lg">
                            <i class="fas fa-users text-blue-600 text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-4 pt-4 border-t border-gray-100">
                        <div class="flex items-center text-sm text-gray-500">
                            <span class="h-2 w-2 bg-blue-500 rounded-full mr-2"></span>
                            System metrics
                        </div>
                    </div>
                </div>

                <!-- Active Users Card -->
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow duration-200">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm font-medium text-gray-500 uppercase tracking-wide">Active Users</p>
                            <p class="text-3xl font-bold text-gray-900 mt-1"><?php echo e($activeUsers); ?></p>
                            <p class="text-sm text-gray-500 mt-1">Currently online</p>
                        </div>
                        <div class="p-3 bg-green-50 rounded-lg">
                            <i class="fas fa-user-check text-green-600 text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-4 pt-4 border-t border-gray-100">
                        <div class="flex items-center text-sm text-gray-500">
                            <span class="h-2 w-2 bg-green-500 rounded-full mr-2"></span>
                            Real-time status
                        </div>
                    </div>
                </div>

                <!-- Recent Activity Card -->
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow duration-200">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm font-medium text-gray-500 uppercase tracking-wide">Recent Logins</p>
                            <p class="text-3xl font-bold text-gray-900 mt-1"><?php echo e($recentLogins); ?></p>
                            <p class="text-sm text-gray-500 mt-1">Last 7 days</p>
                        </div>
                        <div class="p-3 bg-purple-50 rounded-lg">
                            <i class="fas fa-history text-purple-600 text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-4 pt-4 border-t border-gray-100">
                        <div class="flex items-center text-sm text-gray-500">
                            <span class="h-2 w-2 bg-purple-500 rounded-full mr-2"></span>
                            Activity tracking
                        </div>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 px-4 sm:px-6 lg:px-8">
                <!-- Professional User Info Card -->
                <div class="bg-white rounded-xl p-6 border border-gray-200 shadow-sm group">
                    <div class="flex items-center mb-6">
                        <div class="p-3 bg-gray-100 rounded-lg mr-3">
                            <i class="fas fa-id-card text-gray-600 text-xl"></i>
                        </div>
                        <h3 class="text-xl font-bold text-gray-900">Your Profile</h3>
                    </div>
                    
                    <div class="space-y-4">
                        <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-100 hover:bg-blue-50 hover:border-blue-200 transition-all duration-300 transform hover:-translate-y-1 hover:shadow-md">
                            <div class="flex items-center">
                                <i class="fas fa-user-circle text-gray-500 mr-3 transition-colors duration-300 group-hover:text-blue-600"></i>
                                <span class="text-gray-600 font-medium">Username:</span>
                            </div>
                            <span class="text-gray-800 font-semibold"><?php echo e($user->username); ?></span>
                        </div>
                        
                        <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-100 hover:bg-blue-50 hover:border-blue-200 transition-all duration-300 transform hover:-translate-y-1 hover:shadow-md">
                            <div class="flex items-center">
                                <i class="fas fa-signature text-gray-500 mr-3 transition-colors duration-300 group-hover:text-blue-600"></i>
                                <span class="text-gray-600 font-medium">Name:</span>
                            </div>
                            <span class="text-gray-800 font-semibold"><?php echo e($user->name); ?></span>
                        </div>
                        
                        <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-100 hover:bg-blue-50 hover:border-blue-200 transition-all duration-300 transform hover:-translate-y-1 hover:shadow-md">
                            <div class="flex items-center">
                                <i class="fas fa-envelope text-gray-500 mr-3 transition-colors duration-300 group-hover:text-blue-600"></i>
                                <span class="text-gray-600 font-medium">Email:</span>
                            </div>
                            <span class="text-gray-800 font-semibold"><?php echo e($user->email); ?></span>
                        </div>
                        
                        <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-100 hover:bg-blue-50 hover:border-blue-200 transition-all duration-300 transform hover:-translate-y-1 hover:shadow-md">
                            <div class="flex items-center">
                                <i class="fas fa-power-off text-gray-500 mr-3 transition-colors duration-300 group-hover:text-blue-600"></i>
                                <span class="text-gray-600 font-medium">Status:</span>
                            </div>
                            <span class="px-3 py-1 rounded-full text-sm font-semibold 
                                <?php echo e($user->is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                                <?php echo e($user->is_active ? 'Active' : 'Inactive'); ?>

                            </span>
                        </div>
                    </div>
                </div>

                <!-- Professional Quick Actions Card -->
                <div class="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
                    <div class="flex items-center mb-6">
                        <div class="p-3 bg-gray-100 rounded-lg mr-3">
                            <i class="fas fa-bolt text-gray-600 text-xl"></i>
                        </div>
                        <h3 class="text-xl font-bold text-gray-900">Quick Actions</h3>
                    </div>
                    
                    <div class="space-y-4">
                        <a href="<?php echo e(route('profile.edit')); ?>" 
                           class="block w-full text-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg transition-colors duration-200">
                            <i class="fas fa-user-edit mr-2"></i>
                            Edit Profile
                        </a>
                        
                        <button onclick="showLastLogin()" 
                                class="block w-full text-center bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold py-3 px-4 rounded-lg border border-gray-200 transition-colors duration-200">
                            <i class="fas fa-history mr-2"></i>
                            Show Last Login
                        </button>
                    </div>
                    
                    <div id="last-login-info" class="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-100 hidden transition-all duration-300">
                        <div class="flex items-start">
                            <i class="fas fa-info-circle text-blue-500 mt-1 mr-3"></i>
                            <div>
                                <p class="text-blue-800 font-semibold mb-1">Account Information</p>
                                <div class="space-y-2 text-sm text-gray-600">
                                    <?php
                                        $isFirstLogin = !$user->last_login || 
                                                       ($user->wasRecentlyCreated && $user->last_login->diffInSeconds($user->created_at) < 300);
                                    ?>
                                    
                                    <?php if(!$isFirstLogin): ?>
                                        <p>Last login: <span class="font-semibold text-blue-600"><?php echo e($user->last_login->format('M d, Y \a\t g:i A')); ?></span></p>
                                    <?php else: ?>
                                        <p><span class="text-gray-500 italic">First time logging in! Welcome aboard!</span></p>
                                    <?php endif; ?>
                                    <p>Account created: <span class="font-medium text-gray-700"><?php echo e($user->created_at->format('M d, Y \a\t g:i A')); ?></span></p>
                                    <p>Last updated: <span class="font-medium text-gray-700"><?php echo e($user->updated_at->format('M d, Y \a\t g:i A')); ?></span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function showLastLogin() {
            const loginInfo = document.getElementById('last-login-info');
            if (loginInfo.classList.contains('hidden')) {
                loginInfo.classList.remove('hidden');
            } else {
                loginInfo.classList.add('hidden');
            }
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\Prixane Jade\Documents\ELeccion\Laravel\LaravelDashboard\resources\views/dashboard.blade.php ENDPATH**/ ?>